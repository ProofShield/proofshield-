PROOFSHIELD ANDROID PROJECT — SOURCE CODE, NOT AN APK/AAB

Open this folder as a project in Android Studio (desktop or a cloud build environment).
Use JDK 17, Android SDK 35, and Gradle/Android Gradle Plugin compatible with build.gradle.kts.
Build > Generate Signed Bundle / APK > Android App Bundle to create a signed .aab.
Keep the signing key safe and private. Create a Google Play Console developer account,
complete required identity verification, app content declarations, privacy policy,
data safety form, store listing/screenshots, and any testing requirements for your account.
Upload signed AAB to a test track, thoroughly test, then request production access.

IMPORTANT: This source is NOT compiled or device-tested in this environment. Before
publishing, test camera/gallery picker, storage, backups, signatures, printing, and
Android WebView behavior on real phones. The app uses local WebView IndexedDB;
uninstalling/clearing app data can permanently erase records unless exported.

PLAY STORE SAFETY: This is a starter MVP, not court-certified evidence software.
It lacks encrypted cloud backup, accounts, immutable logs, independent timestamps,
verified signatures, SHA-256 photo hashes, and production privacy/retention controls.
Do not advertise it as lawsuit-proof or guarantee evidence admissibility.
Because it processes client PII, review applicable privacy and data protection rules.

Android phone only? Use a trusted cloud Android build service or borrow a computer
with Android Studio. Do not paste your signing key into chats or public repos.
