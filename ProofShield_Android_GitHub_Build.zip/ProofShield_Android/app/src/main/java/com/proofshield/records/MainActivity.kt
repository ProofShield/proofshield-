package com.proofshield.records

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.net.Uri
import android.widget.Toast
import android.content.ActivityNotFoundException
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingJson: String? = null
    private val filePickRequest = 201
    private val saveRequest = 202

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                    startActivityForResult(intent, filePickRequest)
                    true
                } catch (e: ActivityNotFoundException) {
                    chooserCallback = null
                    Toast.makeText(this@MainActivity, "No file picker available", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveJson(filename: String, content: String) {
                runOnUiThread {
                    pendingJson = content
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, filename.take(100).replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                    }
                    startActivityForResult(intent, saveRequest)
                }
            }
        }, "ProofShieldAndroid")
        // Load app assets from a trusted local origin, not an external website.
        web.loadUrl("file:///android_asset/index.html")
    }
    @Deprecated("Legacy callback used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode) {
            filePickRequest -> {
                val result = if(resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                chooserCallback?.onReceiveValue(result)
                chooserCallback = null
            }
            saveRequest -> {
                if(resultCode == RESULT_OK && data?.data != null) {
                    try {
                        contentResolver.openOutputStream(data.data!!)?.use { it.write((pendingJson ?: "").toByteArray(Charsets.UTF_8)) }
                        Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) { Toast.makeText(this, "Save failed", Toast.LENGTH_LONG).show() }
                }
                pendingJson = null
            }
        }
    }
    @Deprecated("Use WebView back navigation")
    override fun onBackPressed() {
        if(web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() { web.removeJavascriptInterface("ProofShieldAndroid"); web.destroy(); super.onDestroy() }
}
